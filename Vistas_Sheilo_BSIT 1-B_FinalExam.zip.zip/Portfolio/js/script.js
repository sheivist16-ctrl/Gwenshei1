function scrollToSlide(slideId) {
      document.getElementById(slideId).scrollIntoView({ behavior: 'smooth' });
    }
    let lastScroll = 0;
    window.addEventListener('scroll', () => {
      const header = document.querySelector('header');
      const currentScroll = window.pageYOffset;
      
      if (currentScroll > 100) {
        header.style.background = 'rgba(5, 0, 18, 0.95)';
      } else {
        header.style.background = 'rgba(5, 0, 18, 0.8)';
      }
      
      lastScroll = currentScroll;
    });